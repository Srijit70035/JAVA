import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.mysql.cj.jdbc.Driver;

public class PS_DeleteApp {

	public static void main(String[] args) throws SQLException {
		
    Driver driver = new Driver();
    DriverManager.registerDriver(driver);
		
	String url = "jdbc:mysql://localhost:3306/ineuron";
	String user = "abc";
	String password = "password";
		
	Connection connection = DriverManager.getConnection(url, user, password);
	String sqlDeleteQuery = "select id,name,addr from student where id=?";
	PreparedStatement pstmt = connection.prepareStatement(sqlDeleteQuery);
		
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter the id:");
	int id = sc.nextInt();
		
	
	
	pstmt.setInt(1, id);
	
	int rowsAffected = pstmt.executeUpdate();
	System.out.println("No of rows affected is:"+rowsAffected);
	
	pstmt.close();
	connection.close();
		
		
		

	}
}
