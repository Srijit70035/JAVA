import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import com.mysql.cj.jdbc.Driver;

public class PS_InsertApp {

	public static void main(String[] args) throws SQLException {
		
    Driver driver = new Driver();
    DriverManager.registerDriver(driver);
		
	String url = "jdbc:mysql://localhost:3306/ineuron";
	String user = "abc";
	String password = "password";
		
	Connection connection = DriverManager.getConnection(url, user, password);
	String sqlInsertQuery = "insert into student('id','name','addr') values(?,?,?)";
	PreparedStatement pstmt = connection.prepareStatement(sqlInsertQuery);
		
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter the id:");
	int id = sc.nextInt();
		
	System.out.println("Enter the name:");
	String name = sc.next();
		
	System.out.println("Enter the address:");
	String addr = sc.next();
	
	pstmt.setInt(1, id);
	pstmt.setString(2,name);
	pstmt.setString(3,addr);
	
	int rowsAffected = pstmt.executeUpdate();
	System.out.println("No of rows Affected is:"+rowsAffected);
	
	pstmt.close();
	connection.close();
		
		
		

	}

}
