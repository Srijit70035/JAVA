import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.mysql.cj.jdbc.Driver;

public class SelectApp {

	public static void main(String[] args) throws SQLException {
		
		Driver driver = new Driver();
		DriverManager.registerDriver(driver);
		
		String url = "jdbc:mysql://localhost:3306/ineuron";
		String user = "abc";
		String password = "password";
		
		Connection connection = DriverManager.getConnection(url, user, password);
		
		Statement statement = connection.createStatement();
		
		String sqlSelectQuery = "select id,name,addr from student";
		ResultSet resultset = statement.executeQuery(sqlSelectQuery);
		
		System.out.println("ID\tNAME\tADDR");
		System.out.println("========================");
		while(resultset.next())
		{
			int id = resultset.getInt(1);
			String name = resultset.getString(2);
			String addr = resultset.getString(3);
			System.out.println(id+"\t"+name+"\t"+addr);

		}
		
		resultset.close();
		statement.close();
		connection.close();
		
		
	}

}
