
public class StringReverse {

	public static void main(String[] args) {
		String s = "iNeuron";
		String r = new StringBuffer(s).reverse().toString();
        System.out.println("String before reverse:  " +s);
        System.out.println("String after reverse:   " +r);
        

	}

}
